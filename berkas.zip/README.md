npm install
npm i --save-dev sequalize-cli
npx sequelize-cli init
membuat setting database di src/databse/config/config.js
npx sequelize-cli db:migrate
npx sequelize-cli db:seed:all
